import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/onboarding_screen.dart';
import 'screens/server_dashboard_screen.dart';
import 'screens/device_list_screen.dart';

void main() {
  runApp(const BovineTrackApp());
}

class BovineTrackApp extends StatelessWidget {
  const BovineTrackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BovineTrack',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const OnboardingScreen(),
      routes: {
        '/onboarding': (context) => const OnboardingScreen(),
        '/dashboard': (context) => const ServerDashboardScreen(),
        '/devices': (context) => const DeviceListScreen(),
      },
    );
  }
}
