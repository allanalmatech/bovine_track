import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ServerDashboardScreen extends StatelessWidget {
  const ServerDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.menu, color: AppColors.primary),
          onPressed: () {},
        ),
        title: const Text(
          'BovineTrack',
          style: TextStyle(
            fontFamily: 'Manrope',
            fontWeight: FontWeight.w900,
            fontSize: 24,
            color: AppColors.primary,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              radius: 20,
              backgroundColor: AppColors.primaryContainer,
              child: const Icon(Icons.person, color: AppColors.onPrimaryContainer),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'System Overview',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: AppColors.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'North Pasture Status',
              style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: 48),
            ),
            const SizedBox(height: 32),
            _buildStatsGrid(),
            const SizedBox(height: 32),
            _buildMapPreview(),
            const SizedBox(height: 32),
            _buildActiveAlerts(),
            const SizedBox(height: 100), // Space for FAB
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        backgroundColor: AppColors.primaryFixed,
        foregroundColor: AppColors.onPrimaryFixed,
        icon: const Icon(Icons.add),
        label: const Text('Deploy Device'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
      ),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildStatsGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: 1.1,
      children: [
        _buildStatCard(
          icon: Icons.memory,
          label: 'Live Fleet',
          value: '14',
          subLabel: 'Connected Devices',
          color: AppColors.surfaceContainerLow,
          iconColor: AppColors.primary,
          iconBg: AppColors.primaryFixed,
        ),
        _buildStatCard(
          icon: Icons.notifications_active,
          label: 'Urgent',
          value: '3',
          subLabel: 'Active Alerts',
          color: AppColors.errorContainer,
          iconColor: AppColors.errorContainer,
          iconBg: AppColors.onErrorContainer,
          textColor: AppColors.onErrorContainer,
        ),
        _buildStatCard(
          icon: Icons.polyline,
          label: 'Mapping',
          value: '5',
          subLabel: 'Zones Created',
          color: AppColors.secondaryContainer,
          iconColor: AppColors.secondaryContainer,
          iconBg: AppColors.onSecondaryContainer,
          textColor: AppColors.onSecondaryContainer,
        ),
        _buildStatCard(
          icon: Icons.bolt,
          label: 'Optimal',
          value: '98%',
          subLabel: 'System Uptime',
          color: AppColors.primaryContainer,
          iconColor: AppColors.primary,
          iconBg: AppColors.primaryFixed,
          textColor: AppColors.primaryFixed,
          isDark: true,
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required String subLabel,
    required Color color,
    required Color iconColor,
    required Color iconBg,
    Color? textColor,
    bool isDark = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              Text(
                label.toUpperCase(),
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                  color: textColor ?? AppColors.onSurfaceVariant,
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontFamily: 'Manrope',
                  fontWeight: FontWeight.w900,
                  fontSize: 32,
                  color: textColor ?? AppColors.primary,
                ),
              ),
              Text(
                subLabel,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: textColor?.withOpacity(0.8) ?? AppColors.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMapPreview() {
    return Container(
      height: 300,
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.surfaceContainer,
        borderRadius: BorderRadius.circular(32),
        image: const DecorationImage(
          image: NetworkImage('https://placeholder.com/map'), // Placeholder for map
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 20,
            left: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.9),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Live Herd Positions',
                    style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary),
                  ),
                  Text(
                    'North Pasture Sector 4',
                    style: TextStyle(fontSize: 12, color: AppColors.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 20,
            child: Row(
              children: [
                _buildMapChip('12 Cattle Active', AppColors.primaryFixed),
                const SizedBox(width: 8),
                _buildMapChip('2 Maintenance', AppColors.tertiaryFixed),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapChip(String label, Color dotColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(9999),
        border: Border.all(color: Colors.white.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveAlerts() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Active Alerts',
              style: TextStyle(fontFamily: 'Manrope', fontWeight: FontWeight.w800, fontSize: 24, color: AppColors.primary),
            ),
            TextButton(
              onPressed: () {},
              child: const Text('View All', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _buildAlertItem(
          title: 'Geofence Breach',
          subtitle: 'Device #8042 (Sector B)',
          time: '2 minutes ago',
          icon: Icons.warning,
          color: AppColors.error,
        ),
        const SizedBox(height: 12),
        _buildAlertItem(
          title: 'Low Battery Critical',
          subtitle: 'Device #2119 (Sector A)',
          time: '15 minutes ago',
          icon: Icons.battery_alert,
          color: AppColors.tertiaryContainer,
        ),
      ],
    );
  }

  Widget _buildAlertItem({
    required String title,
    required String subtitle,
    required String time,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border(left: BorderSide(color: color, width: 4)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.onSurface)),
                Text(subtitle, style: const TextStyle(fontSize: 14, color: AppColors.onSurfaceVariant)),
                const SizedBox(height: 8),
                Text(time, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavItem(Icons.grid_view_rounded, 'Dashboard', true),
          _buildNavItem(Icons.memory, 'Devices', false),
          _buildNavItem(Icons.map, 'Map', false),
          _buildNavItem(Icons.notifications, 'Alerts', false),
          _buildNavItem(Icons.settings, 'Settings', false),
        ],
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isActive ? AppColors.primaryFixed : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(icon, color: isActive ? AppColors.primary : AppColors.onSurfaceVariant),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: isActive ? AppColors.primary : AppColors.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}
